Example golang content 2
