Example golang content
